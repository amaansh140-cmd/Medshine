<?php
header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');
header('Cache-Control: post-check=0, pre-check=0', false);
header('Pragma: no-cache');
require 'api/config.php';
$stmt = $pdo->prepare("SELECT section_key, content_value FROM page_content WHERE page_slug IN ('index', 'global')");
$stmt->execute();
$content = [];
while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
    $content[$row['section_key']] = $row['content_value'];
}
?>
<!DOCTYPE html>

<html class="scroll-smooth" lang="en">
<head>
<meta charset="utf-8"/>
<meta content="width=device-width, initial-scale=1.0" name="viewport"/>
<title>Dr. Priya Jain | Best Skin Specialist &amp; Aesthetic Physician in Mumbai | Medshine Clinic</title>
<meta content="Medshine Clinic in Mumbai by Dr. Priya Jain offers advanced laser rejuvenation, clinical acne scar revision, anti-aging contouring, and regenerative cellular therapies." name="description"/>
<meta content="Dr. Priya Jain | Best Skin Specialist &amp; Aesthetic Physician in Mumbai | Medshine Clinic" property="og:title"/>
<meta content="Medshine Clinic in Mumbai by Dr. Priya Jain offers advanced laser rejuvenation, clinical acne scar revision, anti-aging contouring, and regenerative cellular therapies." property="og:description"/>
<meta content="website" property="og:type"/>
<meta content="https://medshineclinic.comassets/dr_priya_portrait_pink.jpg" property="og:image"/>
<meta content="summary_large_image" name="twitter:card"/>
<meta content="Dr. Priya Jain | Best Skin Specialist &amp; Aesthetic Physician in Mumbai | Medshine Clinic" name="twitter:title"/>
<meta content="Medshine Clinic in Mumbai by Dr. Priya Jain offers advanced laser rejuvenation, clinical acne scar revision, anti-aging contouring, and regenerative cellular therapies." name="twitter:description"/>
<meta content="https://medshineclinic.comassets/dr_priya_portrait_pink.jpg" name="twitter:image"/>
<link href="https://fonts.googleapis.com" rel="preconnect"/>
<link crossorigin="" href="https://fonts.gstatic.com" rel="preconnect"/>
<link href="https://fonts.googleapis.com/css2?family=Playfair+Display:ital,wght@0,400;0,500;0,600;0,700;1,400;1,500&amp;family=Inter:wght@300;400;500;600&amp;display=swap" rel="stylesheet"/>
<script src="https://cdn.tailwindcss.com"></script>
<script>
      tailwind.config = {
        theme: {
          extend: {
            colors: {
              cream: '<?php echo $content["color_bg"] ?? "#FDFBF7"; ?>',
              creamdeep: '<?php echo $content["color_bg"] ?? "#F5F2EA"; ?>',
              ink: '<?php echo $content["color_text"] ?? "#065F46"; ?>',
              inkmute: '<?php echo $content["color_text"] ?? "#059669"; ?>',
              magenta: '<?php echo $content["color_accent"] ?? "#E11D48"; ?>', 
              magentadeep: '<?php echo $content["color_accent"] ?? "#E11D48"; ?>',
            },
            fontFamily: {
              serif: ['"Playfair Display"', 'serif'],
              sans: ['Inter', 'sans-serif'],
            }
          }
        }
      }
    </script>
<style>
      ::selection { background-color: #065F46; color: #FDFBF7; }
      body { background-color: #FDFBF7; color: #065F46; }
      
      .grid-texture {
        background-image: linear-gradient(to right, rgba(26,26,26,0.05) 1px, transparent 1px),
                          linear-gradient(to bottom, rgba(26,26,26,0.05) 1px, transparent 1px);
        background-size: 54px 54px;
      }
      .grid-texture-light {
        background-image: linear-gradient(to right, rgba(255,255,255,0.1) 1px, transparent 1px),
                          linear-gradient(to bottom, rgba(255,255,255,0.1) 1px, transparent 1px);
        background-size: 60px 60px;
      }
      .hover-row { transition: transform 0.35s ease; }
      .hover-row:hover { transform: translateX(-14px); }
      
      .scroll-reveal-layer ::selection { background-color: #FDFBF7; color: #065F46; }
    </style>
  <script type="module" crossorigin src="/assets/modulepreload-polyfill-B5Qt9EMX.js"></script>
  <script type="module" crossorigin src="/assets/animations-UhYGCEAG.js"></script>
  <link rel="stylesheet" crossorigin href="/assets/style-wwR6AwHa.css">
</head>
<body class="font-sans antialiased selection:bg-ink selection:text-cream">
<!-- SVG Defs for Mask and Gooey Filter -->
<!-- Sticky Nav -->
<nav class="fixed top-0 left-0 right-0 z-50 bg-cream/85 backdrop-blur-md border-b border-ink/10">
<div class="max-w-[1240px] mx-auto px-6 md:px-10 h-[68px] flex items-center justify-between">
<a class="flex items-center gap-3" href="/">
<div class="w-7 h-7 rounded-full bg-ink flex items-center justify-center text-cream">
<svg fill="currentColor" height="16" viewbox="0 0 256 256" width="16" xmlns="http://www.w3.org/2000/svg"><path class="reveal-anim" d="M128,24A104,104,0,1,0,232,128,104.11,104.11,0,0,0,128,24Zm43.81,68.19-28.28,66a8,8,0,0,1-3.72,3.72l-66,28.28a8,8,0,0,1-10.36-10.36l28.28-66a8,8,0,0,1,3.72-3.72l66-28.28A8,8,0,0,1,171.81,92.19ZM128,112a16,16,0,1,0,16,16A16,16,0,0,0,128,112Z"></path></svg>
</div>
<span class="font-serif font-semibold tracking-tight text-xl text-ink">Medshine</span>
</a>
<div class="hidden md:flex items-center gap-8 text-sm text-inkmute" id="desktop-nav">
<a class="hover:text-ink transition-colors nav-link" href="team.html">Team</a>
<a class="hover:text-ink transition-colors nav-link" href="treatments.html">Treatments</a>
<a class="hover:text-ink transition-colors nav-link" href="blog.html">Blogs</a>
<a class="hover:text-ink transition-colors nav-link" href="results.html">Results</a>
<a class="hover:text-ink transition-colors nav-link" href="contact.html">Contact</a>
</div>
</div>
</nav>
<!-- Doctor Hero Section -->
<section class="max-w-[1240px] mx-auto px-6 md:px-10 pt-32 pb-20">
<div class="grid grid-cols-1 md:grid-cols-12 gap-12 items-center stagger-group">
<div class="md:col-span-5 reveal-anim">
<div class="relative rounded-[32px] overflow-hidden aspect-[4/5] bg-ink/5 border border-ink/10 shadow-xl">
<picture>
<source media="(max-width: 767px)" srcset="/assets/dr_priya_mobile_hero-BTwAxTqY.jpg"/>
<img alt="Dr. Priya Jain" class="w-full h-full object-cover contrast-105 reveal-fade" src="/assets/dr_priya_portrait_pink-Ci1VF3c0.jpg"/>
</picture>
<div class="absolute bottom-4 left-4 right-4 bg-cream/90 backdrop-blur-md p-4 rounded-2xl border border-ink/10 animate-float">
<span class="text-xs uppercase tracking-widest text-ink font-semibold block">MBBS, FFAC (Fellowships)</span>
<span class="text-xs text-inkmute">Skin Specialist &amp; Aesthetic Physician</span>
</div>
</div>
</div>
<div class="md:col-span-7 reveal-anim">
<span class="text-magenta uppercase text-xs tracking-[0.28em] font-semibold block mb-4">Medical Specialist Profile</span>
<h1 class="font-serif font-medium leading-[0.98] tracking-tight text-ink mb-6 reveal-anim reveal-fade" style="font-size: clamp(2.8rem, 6.5vw, 5.2rem);">
                <?php echo $content['hero_title'] ?? 'Dr. Priya <em class="font-light italic text-inkmute">Jain</em>'; ?>
</h1>
<p class="text-ink text-lg md:text-xl font-serif italic mb-8 leading-relaxed max-w-[36ch] border-l-2 border-ink/20 pl-6">
                <?php echo nl2br($content['hero_subtitle'] ?? '"We do not treat skin as a canvas for cosmetic trends. We treat it as a vital biological organ that flourishes under precision diagnosis and empathetic medical care."'); ?></p>
<p class="text-inkmute text-[16px] leading-relaxed mb-8 max-w-[48ch]">
                <?php echo nl2br($content['about_text'] ?? 'As the visionary founder of Medshine Clinic, Dr. Priya Jain (MBBS, FFAC Fellowships) has dedicated over 15 years to advancing clinical cosmetology and aesthetic services. As a renowned Skin Specialist and Aesthetic Physician, her evidence-based philosophy emphasizes cellular skin health, precision diagnostics, and tailored non-invasive rejuvenation.'); ?></p>
<div class="flex flex-wrap gap-4">
<a class="bg-ink text-cream px-8 py-4 rounded-full text-sm font-semibold uppercase tracking-wider hover:bg-magenta transition-all hover-scale" href="contact.html">
                  Book with Dr. Priya Jain
                </a>
<a class="border border-ink/20 text-ink px-8 py-4 rounded-full text-sm font-semibold uppercase tracking-wider hover:bg-ink/5 transition-all hover-scale" href="#specialties">
                  View Specialties
                </a>
</div>
</div>
</div>
</section>
<!-- Image Slider Section -->
<section class="max-w-[100vw] overflow-hidden mb-28 py-6 relative" id="hero-slider-section">
<!-- Gradient Fades for edges -->
<div class="absolute inset-y-0 left-0 w-12 md:w-32 bg-gradient-to-r from-cream to-transparent z-10 pointer-events-none"></div>
<div class="absolute inset-y-0 right-0 w-12 md:w-32 bg-gradient-to-l from-cream to-transparent z-10 pointer-events-none"></div>
<div class="flex overflow-hidden" id="smooth-slider-container">
<div class="flex gap-4 md:gap-6 pr-4 md:pr-6 flex-none items-center" id="smooth-slider-track" style="will-change: transform;">
<!-- Slide 1 -->
<div class="w-[200px] md:w-[240px] h-[320px] md:h-[420px] flex-none bg-ink/5 rounded-[16px] overflow-hidden shadow-sm border border-ink/10">
<img alt="Clinic Interior" class="w-full h-full object-cover" src="/assets/clinic-room-DT-0E_O2.jpg"/>
</div>
<!-- Slide 2 -->
<div class="w-[200px] md:w-[240px] h-[320px] md:h-[420px] flex-none bg-ink/5 rounded-[16px] overflow-hidden shadow-sm border border-ink/10">
<img alt="Laser Machine" class="w-full h-full object-cover" src="/assets/laser-machine-BDMEq5QD.jpg"/>
</div>
<!-- Slide 3 -->
<div class="w-[200px] md:w-[240px] h-[320px] md:h-[420px] flex-none bg-ink/5 rounded-[16px] overflow-hidden shadow-sm border border-ink/10">
<img alt="Product Shelf" class="w-full h-full object-cover" src="/assets/product-shelf-BtkKn5Gz.jpg"/>
</div>
<!-- Slide 4 -->
<div class="w-[200px] md:w-[240px] h-[320px] md:h-[420px] flex-none bg-ink/5 rounded-[16px] overflow-hidden shadow-sm border border-ink/10">
<img alt="Face Exam" class="w-full h-full object-cover" src="/assets/face-exam-DWbZtlmp.PNG"/>
</div>
<!-- Slide 5 -->
<div class="w-[200px] md:w-[240px] h-[320px] md:h-[420px] flex-none bg-ink/5 rounded-[16px] overflow-hidden shadow-sm border border-ink/10">
<img alt="Hair Treatment" class="w-full h-full object-cover" src="/assets/hair-treatment-swOo_HRQ.PNG"/>
</div>
<!-- Slide 6 -->
<div class="w-[200px] md:w-[240px] h-[320px] md:h-[420px] flex-none bg-ink/5 rounded-[16px] overflow-hidden shadow-sm border border-ink/10">
<img alt="Consultation" class="w-full h-full object-cover" src="/assets/desk-consult-BXHCdwC3.PNG"/>
</div>
<!-- Duplicates for seamless loop -->
<div class="w-[200px] md:w-[240px] h-[320px] md:h-[420px] flex-none bg-ink/5 rounded-[16px] overflow-hidden shadow-sm border border-ink/10">
<img alt="Clinic Interior" class="w-full h-full object-cover" src="/assets/clinic-room-DT-0E_O2.jpg"/>
</div>
<div class="w-[200px] md:w-[240px] h-[320px] md:h-[420px] flex-none bg-ink/5 rounded-[16px] overflow-hidden shadow-sm border border-ink/10">
<img alt="Laser Machine" class="w-full h-full object-cover" src="/assets/laser-machine-BDMEq5QD.jpg"/>
</div>
<div class="w-[200px] md:w-[240px] h-[320px] md:h-[420px] flex-none bg-ink/5 rounded-[16px] overflow-hidden shadow-sm border border-ink/10">
<img alt="Product Shelf" class="w-full h-full object-cover" src="/assets/product-shelf-BtkKn5Gz.jpg"/>
</div>
<div class="w-[200px] md:w-[240px] h-[320px] md:h-[420px] flex-none bg-ink/5 rounded-[16px] overflow-hidden shadow-sm border border-ink/10">
<img alt="Face Exam" class="w-full h-full object-cover" src="/assets/face-exam-DWbZtlmp.PNG"/>
</div>
<div class="w-[200px] md:w-[240px] h-[320px] md:h-[420px] flex-none bg-ink/5 rounded-[16px] overflow-hidden shadow-sm border border-ink/10">
<img alt="Hair Treatment" class="w-full h-full object-cover" src="/assets/hair-treatment-swOo_HRQ.PNG"/>
</div>
<div class="w-[200px] md:w-[240px] h-[320px] md:h-[420px] flex-none bg-ink/5 rounded-[16px] overflow-hidden shadow-sm border border-ink/10">
<img alt="Consultation" class="w-full h-full object-cover" src="/assets/desk-consult-BXHCdwC3.PNG"/>
</div>
</div>
</div>
</section>
<script>
  document.addEventListener("DOMContentLoaded", () => {
    const track = document.getElementById("smooth-slider-track");
    const container = document.getElementById("hero-slider-section");
    if (!track || !container) return;
    
    let speed = 1.2; // base pixels per frame
    let currentSpeed = speed;
    let scrollPos = 0;
    let isHovered = false;
    
    container.addEventListener("mouseenter", () => { isHovered = true; });
    container.addEventListener("mouseleave", () => { isHovered = false; });
    // For touch devices
    container.addEventListener("touchstart", () => { isHovered = true; });
    container.addEventListener("touchend", () => { isHovered = false; });
    
    function animate() {
      if (isHovered) {
        currentSpeed = currentSpeed * 0.92; // smooth deceleration
      } else {
        currentSpeed = currentSpeed + (speed - currentSpeed) * 0.08; // smooth acceleration
      }
      
      scrollPos -= currentSpeed;
      
      // The track width is doubled, we reset at exactly half the track width
      const totalWidth = track.scrollWidth;
      const maxScroll = totalWidth / 2;
      
      if (Math.abs(scrollPos) >= maxScroll) {
        scrollPos += maxScroll;
      }
      
      track.style.transform = `translate3d(${scrollPos}px, 0, 0)`;
      requestAnimationFrame(animate);
    }
    
    requestAnimationFrame(animate);
  });
</script>
<!-- Biography & Credentials Grid -->
<section class="max-w-[1240px] mx-auto px-6 md:px-10 mb-28 border-t border-ink/15 pt-20">
<div class="grid grid-cols-1 md:grid-cols-3 gap-12 stagger-group">
<div class="border-l border-ink/15 pl-8 reveal-anim">
<span class="font-serif text-3xl text-ink font-medium block mb-3">Academic Excellence</span>
<p class="text-inkmute text-sm leading-relaxed">
                Completed her Bachelor of Medicine and Bachelor of Surgery (MBBS) with clinical honors, followed by prestigious FFAC Fellowships, establishing her as an expert Skin Specialist and Aesthetic Physician.
              </p>
</div>
<div class="border-l border-ink/15 pl-8 reveal-anim">
<span class="font-serif text-3xl text-ink font-medium block mb-3">Clinical Philosophy</span>
<p class="text-inkmute text-sm leading-relaxed">
                Pioneered the "Diagnostic First" protocol at Medshine Clinic. Every aesthetic treatment plan begins with a comprehensive evaluation of skin barrier health, lifestyle stressors, and underlying inflammatory markers.
              </p>
</div>
<div class="border-l border-ink/15 pl-8 reveal-anim">
<span class="font-serif text-3xl text-ink font-medium block mb-3">15+ Years Impact</span>
<p class="text-inkmute text-sm leading-relaxed">
                Has successfully managed over 10,000+ complex clinical cosmetology and aesthetic services cases, ranging from chronic cystic acne and melasma to advanced structural aging and laser scar revision.
              </p>
</div>
</div>
</section>
<!-- Achievements Marquee -->
<section class="w-full bg-ink/5 backdrop-blur-md text-ink py-8 md:py-12 mb-20 md:mb-28 overflow-hidden relative z-10 border-y border-ink/10">
<div class="flex whitespace-nowrap marquee-container items-center w-max">
<div class="marquee-content flex items-center">
<!-- Item 1 -->
<div class="flex flex-col items-center justify-center px-12 md:px-24 border-r border-ink/10 min-w-[280px]">
<div class="flex items-baseline text-4xl md:text-[3.2rem] font-serif font-semibold tracking-tight mb-3">
<span class="counter-value" data-target="10000">0</span>
<span class="text-inkmute/90 text-3xl md:text-4xl">+</span>
</div>
<span class="text-[11px] md:text-xs tracking-[0.25em] font-semibold text-inkmute uppercase">Happy Patients</span>
</div>
<!-- Item 2 -->
<div class="flex flex-col items-center justify-center px-12 md:px-24 border-r border-ink/10 min-w-[280px]">
<div class="flex items-baseline text-4xl md:text-[3.2rem] font-serif font-semibold tracking-tight mb-3">
<span class="counter-value" data-target="15">0</span>
<span class="text-inkmute/90 text-3xl md:text-4xl">+ Yrs</span>
</div>
<span class="text-[11px] md:text-xs tracking-[0.25em] font-semibold text-inkmute uppercase">Experience</span>
</div>
<!-- Item 3 -->
<div class="flex flex-col items-center justify-center px-12 md:px-24 border-r border-ink/10 min-w-[280px]">
<div class="flex items-baseline text-4xl md:text-[3.2rem] font-serif font-semibold tracking-tight mb-3">
<span class="counter-value" data-target="50">0</span>
<span class="text-inkmute/90 text-3xl md:text-4xl">+</span>
</div>
<span class="text-[11px] md:text-xs tracking-[0.25em] font-semibold text-inkmute uppercase">Advanced Treatments</span>
</div>
<!-- Item 4 -->
<div class="flex flex-col items-center justify-center px-12 md:px-24 border-r border-ink/10 min-w-[280px]">
<div class="flex items-baseline text-4xl md:text-[3.2rem] font-serif font-semibold tracking-tight mb-3">
<span class="counter-value" data-target="100">0</span>
<span class="text-inkmute/90 text-3xl md:text-4xl">%</span>
</div>
<span class="text-[11px] md:text-xs tracking-[0.25em] font-semibold text-inkmute uppercase">Evidence-Based</span>
</div>
</div>
<!-- Duplicate for seamless scroll -->
<div aria-hidden="true" class="marquee-content flex items-center">
<div class="flex flex-col items-center justify-center px-12 md:px-24 border-r border-ink/10 min-w-[280px]">
<div class="flex items-baseline text-4xl md:text-[3.2rem] font-serif font-semibold tracking-tight mb-3">
<span class="counter-value" data-target="10000">0</span>
<span class="text-inkmute/90 text-3xl md:text-4xl">+</span>
</div>
<span class="text-[11px] md:text-xs tracking-[0.25em] font-semibold text-inkmute uppercase">Happy Patients</span>
</div>
<div class="flex flex-col items-center justify-center px-12 md:px-24 border-r border-ink/10 min-w-[280px]">
<div class="flex items-baseline text-4xl md:text-[3.2rem] font-serif font-semibold tracking-tight mb-3">
<span class="counter-value" data-target="15">0</span>
<span class="text-inkmute/90 text-3xl md:text-4xl">+ Yrs</span>
</div>
<span class="text-[11px] md:text-xs tracking-[0.25em] font-semibold text-inkmute uppercase">Experience</span>
</div>
<div class="flex flex-col items-center justify-center px-12 md:px-24 border-r border-ink/10 min-w-[280px]">
<div class="flex items-baseline text-4xl md:text-[3.2rem] font-serif font-semibold tracking-tight mb-3">
<span class="counter-value" data-target="50">0</span>
<span class="text-inkmute/90 text-3xl md:text-4xl">+</span>
</div>
<span class="text-[11px] md:text-xs tracking-[0.25em] font-semibold text-inkmute uppercase">Advanced Treatments</span>
</div>
<div class="flex flex-col items-center justify-center px-12 md:px-24 border-r border-ink/10 min-w-[280px]">
<div class="flex items-baseline text-4xl md:text-[3.2rem] font-serif font-semibold tracking-tight mb-3">
<span class="counter-value" data-target="100">0</span>
<span class="text-inkmute/90 text-3xl md:text-4xl">%</span>
</div>
<span class="text-[11px] md:text-xs tracking-[0.25em] font-semibold text-inkmute uppercase">Evidence-Based</span>
</div>
</div>
</div>
</section>
<!-- Specialties & Procedures -->
<section class="max-w-[1240px] mx-auto px-6 md:px-10 mb-28 scroll-mt-24" id="specialties">
<div class="grid grid-cols-1 md:grid-cols-2 gap-8 stagger-group">
<div class="border border-ink/10 rounded-[24px] p-8 bg-ink/5 hover:border-ink/30 transition-all reveal-anim">
<h3 class="font-serif text-2xl font-semibold text-ink mb-3">Advanced Laser Rejuvenation</h3>
<p class="text-inkmute text-sm leading-relaxed mb-6">
                Precision fractional laser therapy, vascular pigmentation clearance, and collagen-stimulating optical treatments designed for minimal downtime and maximal tissue renewal.
              </p>
<ul class="text-xs text-ink space-y-2 font-medium">
<li>• Q switch for laser toning</li>
<li>• Pico for Melasma</li>
<li>• Carbon for oily acne prone skin</li>
</ul>
</div>
<div class="border border-ink/10 rounded-[24px] p-8 bg-ink/5 hover:border-ink/30 transition-all reveal-anim">
<h3 class="font-serif text-2xl font-semibold text-ink mb-3">Clinical Acne &amp; Scar Revision</h3>
<p class="text-inkmute text-sm leading-relaxed mb-6">
                Holistic management of active breakouts combined with subcision, TCA cross, and RF microneedling to restore smooth skin architecture and eliminate textural scarring.
              </p>
<ul class="text-xs text-ink space-y-2 font-medium">
<li>• Chronic Cystic &amp; Hormonal Acne Protocols</li>
<li>• Deep Ice-Pick &amp; Boxcar Scar Revision</li>
<li>• Post-Inflammatory Hyperpigmentation (PIH) Cure</li>
</ul>
</div>
<div class="border border-ink/10 rounded-[24px] p-8 bg-ink/5 hover:border-ink/30 transition-all reveal-anim">
<h3 class="font-serif text-2xl font-semibold text-ink mb-3">Non-Surgical Facial Contouring</h3>
<p class="text-inkmute text-sm leading-relaxed mb-6">
                Subtle, anatomical rejuvenation utilizing biocompatible dermal fillers, neuromodulators, and bio-remodeling peptides to lift, hydrate, and restore youthful facial proportions.
              </p>
<ul class="text-xs text-ink space-y-2 font-medium">
<li>• Bio-Remodelling &amp; Skin Boosters</li>
<li>• Structural Jawline &amp; Cheek Contouring</li>
<li>• Dynamic Wrinkle Relaxation</li>
</ul>
</div>
<div class="border border-ink/10 rounded-[24px] p-8 bg-ink/5 hover:border-ink/30 transition-all reveal-anim">
<h3 class="font-serif text-2xl font-semibold text-ink mb-3">Cellular Skin Therapies</h3>
<p class="text-inkmute text-sm leading-relaxed mb-6">
                Harnessing the body's own regenerative growth factors and polynucleotides to repair damaged skin barriers, improve skin elasticity, and reverse photo-aging from within.
              </p>
<ul class="text-xs text-ink space-y-2 font-medium">
<li>• Autologous Platelet-Rich Plasma (PRP)</li>
<li>• Polynucleotide Skin Barrier Repair</li>
<li>• Medical-Grade Exosome Infusions</li>
</ul>
</div>
</div>
</section>
<!-- YouTube Showcase -->
<section class="hidden md:block max-w-[1240px] mx-auto px-6 md:px-10 mb-28">
<div class="grid grid-cols-1 md:grid-cols-12 gap-12 items-center bg-ink/5 rounded-[32px] p-8 md:p-16 border border-ink/10 stagger-group">
<div class="md:col-span-5 reveal-anim">
<div class="inline-flex items-center gap-2 px-3 py-1.5 rounded-full bg-red-600/10 text-red-600 mb-6 border border-red-600/20">
<svg class="w-4 h-4" fill="currentColor" viewbox="0 0 24 24"><path d="M19.615 3.184c-3.604-.246-11.631-.245-15.23 0-3.897.266-4.356 2.62-4.385 8.816.029 6.185.484 8.549 4.385 8.816 3.6.245 11.626.246 15.23 0 3.897-.266 4.356-2.62 4.385-8.816-.029-6.185-.484-8.549-4.385-8.816zm-10.615 12.816v-8l8 3.993-8 4.007z"></path></svg>
<span class="text-[10px] font-bold tracking-widest uppercase">YouTube Channel</span>
</div>
<h2 class="font-serif text-3xl md:text-4xl font-medium leading-tight text-ink mb-4">Medshine Clinic on YouTube</h2>
<p class="text-inkmute text-[16px] leading-relaxed mb-8">
        Join our growing community! Watch live clinical procedures, get expert skincare advice, and learn the science behind our aesthetic treatments from Dr. Priya Jain.
      </p>
<a class="inline-flex items-center gap-3 bg-red-600 text-white px-8 py-4 rounded-full text-sm font-semibold uppercase tracking-wider hover:bg-red-700 transition-all hover-scale shadow-lg shadow-red-600/20" href="https://youtube.com/@mediidermashiineclinic?si=G5MEp_Pfw2n_LUfc" target="_blank">
        Subscribe Now
      </a>
</div>
<div class="md:col-span-7 reveal-anim relative group">
<div class="aspect-video w-full rounded-[24px] overflow-hidden shadow-2xl relative bg-ink/10 border border-ink/10">
<!-- REPLACE 'dQw4w9WgXcQ' with actual video ID -->
<iframe allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen="" class="w-full h-full" frameborder="0" src="https://www.youtube.com/embed/i61EFSao8k4?rel=0&amp;showinfo=0" title="YouTube video player"></iframe>
</div>
<!-- Decorative background blur -->
<div class="absolute -bottom-8 -left-8 w-32 h-32 bg-red-600/10 rounded-full filter blur-2xl z-[-1]"></div>
</div>
</div>
</section>
<!-- CTA Band -->
<!-- Footer -->
<!-- Footer -->
<footer class="bg-ink/5 border-t border-ink/10 text-ink relative overflow-hidden mt-12 md:mt-20">
<div class="max-w-[1240px] mx-auto px-6 md:px-10 pt-12 md:pt-24 pb-8 md:pb-10">
<div class="grid grid-cols-1 md:grid-cols-12 gap-8 md:gap-8 mb-10 md:mb-16 relative z-10 stagger-group">
<!-- Brand Column -->
<div class="md:col-span-4 lg:col-span-4 reveal-anim">
<a class="flex items-center gap-3 mb-6" href="/">
<div class="w-8 h-8 rounded-full bg-ink flex items-center justify-center text-cream">
<svg fill="currentColor" height="18" viewbox="0 0 256 256" width="18" xmlns="http://www.w3.org/2000/svg"><path d="M128,24A104,104,0,1,0,232,128,104.11,104.11,0,0,0,128,24Zm43.81,68.19-28.28,66a8,8,0,0,1-3.72,3.72l-66,28.28a8,8,0,0,1-10.36-10.36l28.28-66a8,8,0,0,1,3.72-3.72l66-28.28A8,8,0,0,1,171.81,92.19ZM128,112a16,16,0,1,0,16,16A16,16,0,0,0,128,112Z"></path></svg>
</div>
<span class="font-serif font-semibold tracking-tight text-2xl text-ink">Medshine</span>
</a>
<p class="text-inkmute text-sm leading-relaxed max-w-[30ch] mb-8">
              Where clinical excellence meets aesthetic artistry. We provide comprehensive skin, hair, and internal health solutions under one roof.
            </p>
<!-- Socials -->
<div class="flex items-center gap-4">
<a aria-label="Instagram" class="w-10 h-10 rounded-full border border-ink/20 flex items-center justify-center text-ink/70 hover:bg-ink hover:text-cream transition-colors hover-scale" href="#">
<svg fill="currentColor" height="18" viewbox="0 0 256 256" width="18" xmlns="http://www.w3.org/2000/svg"><path d="M128,80a48,48,0,1,0,48,48A48.05,48.05,0,0,0,128,80Zm0,80a32,32,0,1,1,32-32A32,32,0,0,1,128,160ZM176,24H80A56.06,56.06,0,0,0,24,80v96a56.06,56.06,0,0,0,56,56h96a56.06,56.06,0,0,0,56-56V80A56.06,56.06,0,0,0,176,24Zm40,152a40,40,0,0,1-40,40H80a40,40,0,0,1-40-40V80A40,40,0,0,1,80,40h96a40,40,0,0,1,40,40ZM192,76a12,12,0,1,1-12-12A12,12,0,0,1,192,76Z"></path></svg>
</a>
<a aria-label="Facebook" class="w-10 h-10 rounded-full border border-ink/20 flex items-center justify-center text-ink/70 hover:bg-ink hover:text-cream transition-colors hover-scale" href="#">
<svg fill="currentColor" height="18" viewbox="0 0 256 256" width="18" xmlns="http://www.w3.org/2000/svg"><path d="M128,24A104,104,0,1,0,232,128,104.11,104.11,0,0,0,128,24Zm8,191.63V152h24a8,8,0,0,0,0-16H136V112a16,16,0,0,1,16-16h16a8,8,0,0,0,0-16H152a32,32,0,0,0-32,32v24H96a8,8,0,0,0,0,16h24v63.63a88,88,0,1,1,16,0Z"></path></svg>
</a>
<a aria-label="WhatsApp" class="w-10 h-10 rounded-full border border-ink/20 flex items-center justify-center text-ink/70 hover:bg-ink hover:text-cream transition-colors hover-scale" href="https://wa.me/917506251933">
<svg fill="currentColor" height="18" viewbox="0 0 256 256" width="18" xmlns="http://www.w3.org/2000/svg"><path d="M187.58,144.84l-32-16a8,8,0,0,0-8,.5l-14.69,9.8a40.55,40.55,0,0,1-16-16l9.8-14.69a8,8,0,0,0,.5-8l-16-32A8,8,0,0,0,104,64a40,40,0,0,0-40,40,88.1,88.1,0,0,0,88,88,40,40,0,0,0,40-40A8,8,0,0,0,187.58,144.84ZM152,176a72.08,72.08,0,0,1-72-72A24,24,0,0,1,99.29,80.46l11.48,23-7.7,11.55a8,8,0,0,0-.93,7.67c3.92,10.93,12.72,19.73,23.65,23.65a8,8,0,0,0,7.67-.93l11.55-7.7,23,11.48A24,24,0,0,1,152,176ZM128,24A104,104,0,0,0,36.18,176.88L24.83,210.93a16,16,0,0,0,20.24,20.24l34.05-11.35A104,104,0,1,0,128,24Zm0,192a87.87,87.87,0,0,1-44.06-11.81,8,8,0,0,0-6.54-.67L44,214.6l11.08-33.26a8,8,0,0,0-.67-6.54A88,88,0,1,1,128,216Z"></path></svg>
</a>
</div>
</div>
<!-- Main Treatments -->
<div class="md:col-span-3 lg:col-span-3 reveal-anim">
<h4 class="font-serif font-semibold text-ink text-lg mb-6">Main Treatments</h4>
<ul class="space-y-3 text-sm text-inkmute">
<li><a class="hover:text-ink transition-colors" href="treatments.html">Laser Hair Reduction</a></li>
<li><a class="hover:text-ink transition-colors" href="treatments.html">Acne &amp; Scar Treatments</a></li>
<li><a class="hover:text-ink transition-colors" href="treatments.html">Anti-Aging &amp; Injectables</a></li>
<li><a class="hover:text-ink transition-colors" href="treatments.html">Regenerative Medicine</a></li>
<li><a class="hover:text-ink transition-colors" href="treatments.html">Hair Restoration</a></li>
</ul>
</div>
<!-- Quick Links -->
<div class="md:col-span-2 lg:col-span-2 reveal-anim">
<h4 class="font-serif font-semibold text-ink text-lg mb-6">Explore</h4>
<ul class="space-y-3 text-sm text-inkmute">
<li><a class="hover:text-ink transition-colors" href="dr-ankur.html">Our Team</a></li>
<li><a class="hover:text-ink transition-colors" href="treatments.html">All Services</a></li>
<li><a class="hover:text-ink transition-colors" href="blog.html">Health Blog</a></li>
<li><a class="hover:text-ink transition-colors" href="contact.html">Book Online</a></li>
</ul>
</div>
<!-- Contact Info -->
<div class="md:col-span-3 lg:col-span-3 reveal-anim">
<h4 class="font-serif font-semibold text-ink text-lg mb-6">Contact Us</h4>
<ul class="space-y-4 text-sm text-inkmute">
<li class="flex gap-3">
<svg class="flex-shrink-0 text-ink mt-0.5" fill="currentColor" height="16" viewbox="0 0 256 256" width="16" xmlns="http://www.w3.org/2000/svg"><path d="M128,16a88.1,88.1,0,0,0-88,88c0,75.3,80,132.17,83.41,134.55a8,8,0,0,0,9.18,0C136,236.17,216,179.3,216,104A88.1,88.1,0,0,0,128,16Zm0,56a32,32,0,1,1-32,32A32,32,0,0,1,128,72Z"></path></svg>
<span>Unit shop no 1 ground floor Sarvodya chs near Bangur Nagar metro station, Shastri nagar Road no 1 next to The Tree house School Goregaon West Mumbai Maharashtra 400104</span>
</li>
<li class="flex gap-3 items-center">
<svg class="flex-shrink-0 text-ink" fill="currentColor" height="16" viewbox="0 0 256 256" width="16" xmlns="http://www.w3.org/2000/svg"><path d="M222.37,158.46l-47.11-21.11-.13-.06a16,16,0,0,0-15.17,1.4,8.12,8.12,0,0,0-.75.56L134.87,160c-15.42-7.49-31.34-23.41-38.83-38.83l20.78-24.34a8.12,8.12,0,0,0,.56-.75,16,16,0,0,0,1.4-15.17l-.06-.13L97.66,33.64m0,0A16,16,0,0,0,82,24H39.86A15.92,15.92,0,0,0,24,39.69C27.23,121.72,94.28,188.77,176.31,212A15.92,15.92,0,0,0,192,196.14V154a16,16,0,0,0-9.63-14.63Z"></path></svg>
<a class="hover:text-ink transition-colors" href="tel:+917506251933">+91 75062 51933</a>
</li>
<li class="flex gap-3 items-center">
<svg class="flex-shrink-0 text-ink" fill="currentColor" height="16" viewbox="0 0 256 256" width="16" xmlns="http://www.w3.org/2000/svg"><path d="M224,48H32A16,16,0,0,0,16,64V192a16,16,0,0,0,16,16H224a16,16,0,0,0,16-16V64A16,16,0,0,0,224,48ZM203.43,64,128,133.15,52.57,64ZM224,192H32V74.89l90.58,83.08a8,8,0,0,0,10.84,0L224,74.89Z"></path></svg>
<a class="hover:text-ink transition-colors" href="mailto:contact@medshineclinic.com">contact@medshineclinic.com</a>
</li>
<li class="flex gap-3 items-start">
<svg class="flex-shrink-0 text-ink mt-0.5" fill="currentColor" height="16" viewbox="0 0 256 256" width="16" xmlns="http://www.w3.org/2000/svg"><path d="M128,24A104,104,0,1,0,232,128,104.11,104.11,0,0,0,128,24Zm0,192a88,88,0,1,1,88-88A88.1,88.1,0,0,1,128,216Zm64-88a8,8,0,0,1-8,8H128a8,8,0,0,1-8-8V72a8,8,0,0,1,16,0v48h48A8,8,0,0,1,192,128Z"></path></svg>
<div>
  12-9 PM (Mon-Sat)<br/>
<span class="text-xs opacity-75">Sun by appointment</span>
</div>
</li>
</ul>
</div>
</div>
<div class="border-t border-ink/10 pt-8 flex flex-col md:flex-row justify-between items-center gap-4 relative z-10">
<div class="text-ink/50 text-xs">© 2026 Medshine Clinic. All rights reserved.</div>
</div>
</div>
</footer>
<!-- Floating WhatsApp Button -->
<a aria-label="Chat on WhatsApp" class="whatsapp-float" href="https://wa.me/917506251933" target="_blank">
<svg fill="currentColor" height="32" viewbox="0 0 448 512" width="32" xmlns="http://www.w3.org/2000/svg">
<path d="M380.9 97.1C339 55.1 283.2 32 223.9 32c-122.4 0-222 99.6-222 222 0 39.1 10.2 77.3 29.6 111L0 480l117.7-30.9c32.4 17.7 68.9 27 106.1 27h.1c122.3 0 224.1-99.6 224.1-222 0-59.3-25.2-115-67.1-157zm-157 341.6c-33.2 0-65.7-8.9-94-25.7l-6.7-4-69.8 18.3L72 359.2l-4.4-7c-18.5-29.4-28.2-63.3-28.2-98.2 0-101.7 82.8-184.5 184.6-184.5 49.3 0 95.6 19.2 130.4 54.1 34.8 34.9 56.2 81.2 56.1 130.5 0 101.8-84.9 184.6-186.6 184.6zm101.2-138.2c-5.5-2.8-32.8-16.2-37.9-18-5.1-1.9-8.8-2.8-12.5 2.8-3.7 5.6-14.3 18-17.6 21.8-3.2 3.7-6.5 4.2-12 1.4-32.6-16.3-54-29.1-75.5-66-5.7-9.8 5.7-9.1 16.3-30.3 1.8-3.7 .9-6.9-.5-9.7-1.4-2.8-12.5-30.1-17.1-41.2-4.5-10.8-9.1-9.3-12.5-9.5-3.2-.2-6.9-.2-10.6-.2-3.7 0-9.7 1.4-14.8 6.9-5.1 5.6-19.4 19-19.4 46.3 0 27.3 19.9 53.7 22.6 57.4 2.8 3.7 39.1 59.7 94.8 83.8 35.2 15.2 49 16.5 66.6 13.9 10.7-1.6 32.8-13.4 37.4-26.4 4.6-13 4.6-24.1 3.2-26.4-1.3-2.5-5-3.9-10.5-6.6z"></path>
</svg>
<!-- Tooltip -->
<span class="absolute right-full mr-4 bg-ink text-cream text-sm px-3 py-1.5 rounded-lg opacity-0 group-hover:opacity-100 transition-opacity whitespace-nowrap pointer-events-none font-sans">
        Chat with us
      </span>
</a>
</body>
</html>

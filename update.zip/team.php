<?php
require 'api/config.php';
$stmt = $pdo->prepare("SELECT section_key, content_value FROM page_content WHERE page_slug IN ('team', 'global')");
$stmt->execute();
$content = [];
while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
    $content[$row['section_key']] = $row['content_value'];
}
?>
<!DOCTYPE html>

<html class="scroll-smooth" lang="en">
<head>
<meta charset="utf-8"/>
<meta content="width=device-width, initial-scale=1.0" name="viewport"/>
<title>Team | Medshine Clinic - Advanced Skin &amp; Hair Care in Mumbai</title>
<meta content="Learn more about Team at Medshine Clinic, Mumbai. Dr. Priya Jain offers advanced, evidence-based clinical cosmetology and aesthetic treatments." name="description"/>
<meta content="Team | Medshine Clinic - Advanced Skin &amp; Hair Care in Mumbai" property="og:title"/>
<meta content="Learn more about Team at Medshine Clinic, Mumbai. Dr. Priya Jain offers advanced, evidence-based clinical cosmetology and aesthetic treatments." property="og:description"/>
<meta content="website" property="og:type"/>
<meta content="https://medshineclinic.comassets/dr_priya_portrait_pink.jpg" property="og:image"/>
<meta content="summary_large_image" name="twitter:card"/>
<meta content="Team | Medshine Clinic - Advanced Skin &amp; Hair Care in Mumbai" name="twitter:title"/>
<meta content="Learn more about Team at Medshine Clinic, Mumbai. Dr. Priya Jain offers advanced, evidence-based clinical cosmetology and aesthetic treatments." name="twitter:description"/>
<meta content="https://medshineclinic.comassets/dr_priya_portrait_pink.jpg" name="twitter:image"/>
<link href="https://fonts.googleapis.com" rel="preconnect"/>
<link crossorigin="" href="https://fonts.gstatic.com" rel="preconnect"/>
<link href="https://fonts.googleapis.com/css2?family=Playfair+Display:ital,wght@0,400;0,500;0,600;0,700;1,400;1,500&amp;family=Inter:wght@300;400;500;600&amp;display=swap" rel="stylesheet"/>
<script src="https://cdn.tailwindcss.com"></script>
<script>
      tailwind.config = {
        theme: {
          extend: {
            colors: {
              cream: '<?php echo $content["color_bg"] ?? "#FDFBF7"; ?>',
              creamdeep: '<?php echo $content["color_bg"] ?? "#F5F2EA"; ?>',
              ink: '<?php echo $content["color_text"] ?? "#065F46"; ?>',
              inkmute: '<?php echo $content["color_text"] ?? "#059669"; ?>',
              magenta: '<?php echo $content["color_accent"] ?? "#E11D48"; ?>', 
              magentadeep: '<?php echo $content["color_accent"] ?? "#E11D48"; ?>',
            },
            fontFamily: {
              serif: ['"Playfair Display"', 'serif'],
              sans: ['Inter', 'sans-serif'],
            }
          }
        }
      }
    </script>
<style>
      ::selection { background-color: #065F46; color: #FDFBF7; }
      body { background-color: #FDFBF7; color: #065F46; }
      
      .grid-texture {
        background-image: linear-gradient(to right, rgba(26,26,26,0.05) 1px, transparent 1px),
                          linear-gradient(to bottom, rgba(26,26,26,0.05) 1px, transparent 1px);
        background-size: 54px 54px;
      }
      .grid-texture-light {
        background-image: linear-gradient(to right, rgba(255,255,255,0.1) 1px, transparent 1px),
                          linear-gradient(to bottom, rgba(255,255,255,0.1) 1px, transparent 1px);
        background-size: 60px 60px;
      }
      .hover-row { transition: transform 0.35s ease; }
      .hover-row:hover { transform: translateX(-14px); }
      
      /* Inverted Reveal Layer Selection */
      .scroll-reveal-layer ::selection { background-color: #FDFBF7; color: #065F46; }
    </style>
  <script type="module" crossorigin src="/assets/modulepreload-polyfill-B5Qt9EMX.js"></script>
  <script type="module" crossorigin src="/assets/animations-UhYGCEAG.js"></script>
  <link rel="stylesheet" crossorigin href="/assets/style-wwR6AwHa.css">
</head>
<body class="font-sans antialiased selection:bg-ink selection:text-cream">
<!-- SVG Defs for Mask and Gooey Filter -->
<!-- Sticky Nav (Above all layers) -->
<nav class="fixed top-0 left-0 right-0 z-50 bg-cream/85 backdrop-blur-md border-b border-ink/10">
<div class="max-w-[1240px] mx-auto px-6 md:px-10 h-[68px] flex items-center justify-between">
<a class="flex items-center gap-3" href="/">
<div class="w-7 h-7 rounded-full bg-ink flex items-center justify-center text-cream">
<svg fill="currentColor" height="16" viewbox="0 0 256 256" width="16" xmlns="http://www.w3.org/2000/svg"><path class="reveal-anim" d="M128,24A104,104,0,1,0,232,128,104.11,104.11,0,0,0,128,24Zm43.81,68.19-28.28,66a8,8,0,0,1-3.72,3.72l-66,28.28a8,8,0,0,1-10.36-10.36l28.28-66a8,8,0,0,1,3.72-3.72l66-28.28A8,8,0,0,1,171.81,92.19ZM128,112a16,16,0,1,0,16,16A16,16,0,0,0,128,112Z"></path></svg>
</div>
<span class="font-serif font-semibold tracking-tight text-xl text-ink">Medshine</span>
</a>
<div class="hidden md:flex items-center gap-8 text-sm text-inkmute" id="desktop-nav">
<a class="hover:text-ink transition-colors nav-link" href="team.html">Team</a>
<a class="hover:text-ink transition-colors nav-link" href="treatments.html">Treatments</a>
<a class="hover:text-ink transition-colors nav-link" href="blog.html">Blogs</a>
<a class="hover:text-ink transition-colors nav-link" href="results.html">Results</a>
<a class="hover:text-ink transition-colors nav-link" href="contact.html">Contact</a>
</div>
</div>
</nav>
<!-- Manifesto Hero -->
<section class="max-w-[1240px] mx-auto px-6 md:px-10 pt-32 pb-16">
<div class="flex items-center gap-4 mb-8">
<span class="text-magenta uppercase text-xs tracking-[0.28em] font-semibold">Our Team</span>
<div class="flex-1 h-px bg-ink/15"></div>
<span class="text-inkmute text-sm">Since 2023</span>
</div>
<h1 class="font-serif font-medium leading-[0.95] tracking-tight text-ink max-w-[15ch] mb-8 reveal-anim reveal-fade" style="font-size: clamp(2.7rem, 8.5vw, 7.8rem);"><?php echo $content['page_title'] ?? 'Our Dedicated <em class="font-light italic text-inkmute">Team</em>'; ?></h1>
<p class="text-[17px] md:text-[19px] text-inkmute max-w-[48ch] leading-relaxed mb-10 font-light reveal-anim">Meet the experienced medical professionals dedicated to your clinical health and aesthetic care.</p>
<div class="flex flex-wrap items-center gap-4">
<a class="bg-magenta text-cream px-8 py-4 rounded-full font-medium hover:bg-magentadeep transition-colors flex items-center gap-2 hover-scale" href="treatments.html">
              Explore Our Treatments
              <svg fill="currentColor" height="16" viewbox="0 0 256 256" width="16" xmlns="http://www.w3.org/2000/svg"><path class="reveal-anim" d="M200,64V168a8,8,0,0,1-16,0V83.31L69.66,197.66a8,8,0,0,1-11.32-11.32L172.69,72H88a8,8,0,0,1,0-16H192A8,8,0,0,1,200,64Z"></path></svg>
</a>
<a class="flex items-center gap-3 text-ink hover:text-inkmute transition-colors font-medium" href="#doctors">
<div class="w-9 h-9 rounded-full border border-ink/20 flex items-center justify-center">
<svg fill="currentColor" height="16" viewbox="0 0 256 256" width="16" xmlns="http://www.w3.org/2000/svg"><path class="reveal-anim" d="M205.66,117.66a8,8,0,0,1-11.32,0L136,59.31V216a8,8,0,0,1-16,0V59.31L61.66,117.66a8,8,0,0,1-11.32-11.32l72-72a8,8,0,0,1,11.32,0l72,72A8,8,0,0,1,205.66,117.66Z" transform="rotate(180 128 128)"></path></svg>
</div>
              Meet Our Doctors
            </a>
</div>
</section>
<!-- Full-bleed Gradient/Texture Strip -->
<!-- Why we exist block -->
<!-- Proof List -->
<!-- Meet Our Doctors Section -->
<section class="max-w-[1240px] mx-auto px-6 md:px-10 mb-32 scroll-mt-24" id="doctors">
<div class="flex flex-col md:flex-row md:justify-between md:items-end mb-16 gap-6">
<div>
<span class="text-magenta uppercase text-xs tracking-[0.28em] font-semibold block mb-4">Medical Leadership</span>
<h2 class="font-serif font-medium text-ink leading-none tracking-tight reveal-anim reveal-fade" style="font-size: clamp(2.2rem, 5vw, 4.2rem);">
                Meet Our <em class="font-light italic text-inkmute">Physicians</em>
</h2>
</div>
<p class="text-inkmute text-sm max-w-[38ch] reveal-anim">
              Our clinic is spearheaded by experienced doctors who combine deep medical diagnostics with advanced clinical cosmetology and aesthetic services.
            </p>
</div>
<div class="grid grid-cols-1 md:grid-cols-2 gap-8 stagger-group">
<!-- Doctor: Dr. Ankur Jain -->
<div class="border border-ink/10 rounded-[28px] p-8 md:p-10 bg-ink/5 flex flex-col justify-between relative overflow-hidden group reveal-anim">
<div>
<div class="flex items-center gap-4 mb-6">
<img alt="Dr. Ankur Jain" class="w-16 h-16 rounded-full object-cover object-top border-2 border-ink/15 shadow-md flex-shrink-0 reveal-fade" src="/assets/dr_ankur_portrait-DkLs7Oa7.jpg"/>
<div>
<h3 class="font-serif font-semibold text-2xl text-ink reveal-anim">Dr. Ankur Jain</h3>
<p class="text-xs uppercase tracking-widest text-inkmute mt-1">Internal Medicine &amp; Critical Care Specialist</p>
</div>
</div>
<p class="text-inkmute text-[15.5px] leading-relaxed mb-8 reveal-anim">
                  Dr. Ankur Jain is a renowned specialist in Internal Medicine, General Physician care, Critical Care (Intensivist), Cardiology/Diabetology, and Rheumatology. Dedicated to evidence-based practice, Dr. Ankur Jain ensures every patient achieves lasting physiological balance and vital health.
                </p>
</div>
<div class="border-t border-ink/10 pt-6 flex flex-wrap justify-between items-center gap-4 text-sm text-ink font-medium">
<div>
<span class="block">Specialties: Internal Medicine, Cardiology/Diabetology &amp; Critical Care</span>
<span class="text-xs text-inkmute uppercase tracking-wider">M.B.B.S, M.D (Intensivist &amp; Physician)</span>
</div>
<a class="inline-flex items-center gap-2 bg-ink text-cream px-5 py-2.5 rounded-full text-xs font-semibold uppercase tracking-wider hover:bg-magenta transition-colors hover-scale" href="dr-ankur.html">
                  Know More
                  <svg fill="currentColor" height="12" viewbox="0 0 256 256" width="12" xmlns="http://www.w3.org/2000/svg"><path d="M200,64V168a8,8,0,0,1-16,0V83.31L69.66,197.66a8,8,0,0,1-11.32-11.32L172.69,72H88a8,8,0,0,1,0-16H192A8,8,0,0,1,200,64Z"></path></svg>
</a>
</div>
</div>
</div>
</section>
<!-- Patient Testimonials Bento Grid -->
<!-- Values Grid -->
<!-- CTA Band -->
<!-- Footer -->
<!-- Footer -->
<footer class="bg-ink/5 border-t border-ink/10 text-ink relative overflow-hidden mt-12 md:mt-20">
<div class="max-w-[1240px] mx-auto px-6 md:px-10 pt-12 md:pt-24 pb-8 md:pb-10">
<div class="grid grid-cols-1 md:grid-cols-12 gap-8 md:gap-8 mb-10 md:mb-16 relative z-10 stagger-group">
<!-- Brand Column -->
<div class="md:col-span-4 lg:col-span-4 reveal-anim">
<a class="flex items-center gap-3 mb-6" href="/">
<div class="w-8 h-8 rounded-full bg-ink flex items-center justify-center text-cream">
<svg fill="currentColor" height="18" viewbox="0 0 256 256" width="18" xmlns="http://www.w3.org/2000/svg"><path d="M128,24A104,104,0,1,0,232,128,104.11,104.11,0,0,0,128,24Zm43.81,68.19-28.28,66a8,8,0,0,1-3.72,3.72l-66,28.28a8,8,0,0,1-10.36-10.36l28.28-66a8,8,0,0,1,3.72-3.72l66-28.28A8,8,0,0,1,171.81,92.19ZM128,112a16,16,0,1,0,16,16A16,16,0,0,0,128,112Z"></path></svg>
</div>
<span class="font-serif font-semibold tracking-tight text-2xl text-ink">Medshine</span>
</a>
<p class="text-inkmute text-sm leading-relaxed max-w-[30ch] mb-8">
              Where clinical excellence meets aesthetic artistry. We provide comprehensive skin, hair, and internal health solutions under one roof.
            </p>
<!-- Socials -->
<div class="flex items-center gap-4">
<a aria-label="Instagram" class="w-10 h-10 rounded-full border border-ink/20 flex items-center justify-center text-ink/70 hover:bg-ink hover:text-cream transition-colors hover-scale" href="#">
<svg fill="currentColor" height="18" viewbox="0 0 256 256" width="18" xmlns="http://www.w3.org/2000/svg"><path d="M128,80a48,48,0,1,0,48,48A48.05,48.05,0,0,0,128,80Zm0,80a32,32,0,1,1,32-32A32,32,0,0,1,128,160ZM176,24H80A56.06,56.06,0,0,0,24,80v96a56.06,56.06,0,0,0,56,56h96a56.06,56.06,0,0,0,56-56V80A56.06,56.06,0,0,0,176,24Zm40,152a40,40,0,0,1-40,40H80a40,40,0,0,1-40-40V80A40,40,0,0,1,80,40h96a40,40,0,0,1,40,40ZM192,76a12,12,0,1,1-12-12A12,12,0,0,1,192,76Z"></path></svg>
</a>
<a aria-label="Facebook" class="w-10 h-10 rounded-full border border-ink/20 flex items-center justify-center text-ink/70 hover:bg-ink hover:text-cream transition-colors hover-scale" href="#">
<svg fill="currentColor" height="18" viewbox="0 0 256 256" width="18" xmlns="http://www.w3.org/2000/svg"><path d="M128,24A104,104,0,1,0,232,128,104.11,104.11,0,0,0,128,24Zm8,191.63V152h24a8,8,0,0,0,0-16H136V112a16,16,0,0,1,16-16h16a8,8,0,0,0,0-16H152a32,32,0,0,0-32,32v24H96a8,8,0,0,0,0,16h24v63.63a88,88,0,1,1,16,0Z"></path></svg>
</a>
<a aria-label="WhatsApp" class="w-10 h-10 rounded-full border border-ink/20 flex items-center justify-center text-ink/70 hover:bg-ink hover:text-cream transition-colors hover-scale" href="https://wa.me/917506251933">
<svg fill="currentColor" height="18" viewbox="0 0 256 256" width="18" xmlns="http://www.w3.org/2000/svg"><path d="M187.58,144.84l-32-16a8,8,0,0,0-8,.5l-14.69,9.8a40.55,40.55,0,0,1-16-16l9.8-14.69a8,8,0,0,0,.5-8l-16-32A8,8,0,0,0,104,64a40,40,0,0,0-40,40,88.1,88.1,0,0,0,88,88,40,40,0,0,0,40-40A8,8,0,0,0,187.58,144.84ZM152,176a72.08,72.08,0,0,1-72-72A24,24,0,0,1,99.29,80.46l11.48,23-7.7,11.55a8,8,0,0,0-.93,7.67c3.92,10.93,12.72,19.73,23.65,23.65a8,8,0,0,0,7.67-.93l11.55-7.7,23,11.48A24,24,0,0,1,152,176ZM128,24A104,104,0,0,0,36.18,176.88L24.83,210.93a16,16,0,0,0,20.24,20.24l34.05-11.35A104,104,0,1,0,128,24Zm0,192a87.87,87.87,0,0,1-44.06-11.81,8,8,0,0,0-6.54-.67L44,214.6l11.08-33.26a8,8,0,0,0-.67-6.54A88,88,0,1,1,128,216Z"></path></svg>
</a>
</div>
</div>
<!-- Main Treatments -->
<div class="md:col-span-3 lg:col-span-3 reveal-anim">
<h4 class="font-serif font-semibold text-ink text-lg mb-6">Main Treatments</h4>
<ul class="space-y-3 text-sm text-inkmute">
<li><a class="hover:text-ink transition-colors" href="treatments.html">Laser Hair Reduction</a></li>
<li><a class="hover:text-ink transition-colors" href="treatments.html">Acne &amp; Scar Treatments</a></li>
<li><a class="hover:text-ink transition-colors" href="treatments.html">Anti-Aging &amp; Injectables</a></li>
<li><a class="hover:text-ink transition-colors" href="treatments.html">Regenerative Medicine</a></li>
<li><a class="hover:text-ink transition-colors" href="treatments.html">Hair Restoration</a></li>
</ul>
</div>
<!-- Quick Links -->
<div class="md:col-span-2 lg:col-span-2 reveal-anim">
<h4 class="font-serif font-semibold text-ink text-lg mb-6">Explore</h4>
<ul class="space-y-3 text-sm text-inkmute">
<li><a class="hover:text-ink transition-colors" href="dr-ankur.html">Our Team</a></li>
<li><a class="hover:text-ink transition-colors" href="treatments.html">All Services</a></li>
<li><a class="hover:text-ink transition-colors" href="blog.html">Health Blog</a></li>
<li><a class="hover:text-ink transition-colors" href="contact.html">Book Online</a></li>
</ul>
</div>
<!-- Contact Info -->
<div class="md:col-span-3 lg:col-span-3 reveal-anim">
<h4 class="font-serif font-semibold text-ink text-lg mb-6">Contact Us</h4>
<ul class="space-y-4 text-sm text-inkmute">
<li class="flex gap-3">
<svg class="flex-shrink-0 text-ink mt-0.5" fill="currentColor" height="16" viewbox="0 0 256 256" width="16" xmlns="http://www.w3.org/2000/svg"><path d="M128,16a88.1,88.1,0,0,0-88,88c0,75.3,80,132.17,83.41,134.55a8,8,0,0,0,9.18,0C136,236.17,216,179.3,216,104A88.1,88.1,0,0,0,128,16Zm0,56a32,32,0,1,1-32,32A32,32,0,0,1,128,72Z"></path></svg>
<span>Unit shop no 1 ground floor Sarvodya chs near Bangur Nagar metro station, Shastri nagar Road no 1 next to The Tree house School Goregaon West Mumbai Maharashtra 400104</span>
</li>
<li class="flex gap-3 items-center">
<svg class="flex-shrink-0 text-ink" fill="currentColor" height="16" viewbox="0 0 256 256" width="16" xmlns="http://www.w3.org/2000/svg"><path d="M222.37,158.46l-47.11-21.11-.13-.06a16,16,0,0,0-15.17,1.4,8.12,8.12,0,0,0-.75.56L134.87,160c-15.42-7.49-31.34-23.41-38.83-38.83l20.78-24.34a8.12,8.12,0,0,0,.56-.75,16,16,0,0,0,1.4-15.17l-.06-.13L97.66,33.64m0,0A16,16,0,0,0,82,24H39.86A15.92,15.92,0,0,0,24,39.69C27.23,121.72,94.28,188.77,176.31,212A15.92,15.92,0,0,0,192,196.14V154a16,16,0,0,0-9.63-14.63Z"></path></svg>
<a class="hover:text-ink transition-colors" href="tel:+917506251933">+91 75062 51933</a>
</li>
<li class="flex gap-3 items-center">
<svg class="flex-shrink-0 text-ink" fill="currentColor" height="16" viewbox="0 0 256 256" width="16" xmlns="http://www.w3.org/2000/svg"><path d="M224,48H32A16,16,0,0,0,16,64V192a16,16,0,0,0,16,16H224a16,16,0,0,0,16-16V64A16,16,0,0,0,224,48ZM203.43,64,128,133.15,52.57,64ZM224,192H32V74.89l90.58,83.08a8,8,0,0,0,10.84,0L224,74.89Z"></path></svg>
<a class="hover:text-ink transition-colors" href="mailto:contact@medshineclinic.com">contact@medshineclinic.com</a>
</li>
<li class="flex gap-3 items-start">
<svg class="flex-shrink-0 text-ink mt-0.5" fill="currentColor" height="16" viewbox="0 0 256 256" width="16" xmlns="http://www.w3.org/2000/svg"><path d="M128,24A104,104,0,1,0,232,128,104.11,104.11,0,0,0,128,24Zm0,192a88,88,0,1,1,88-88A88.1,88.1,0,0,1,128,216Zm64-88a8,8,0,0,1-8,8H128a8,8,0,0,1-8-8V72a8,8,0,0,1,16,0v48h48A8,8,0,0,1,192,128Z"></path></svg>
<div>
  12-9 PM (Mon-Sat)<br/>
<span class="text-xs opacity-75">Sun by appointment</span>
</div>
</li>
</ul>
</div>
</div>
<div class="border-t border-ink/10 pt-8 flex flex-col md:flex-row justify-between items-center gap-4 relative z-10">
<div class="text-ink/50 text-xs">© 2026 Medshine Clinic. All rights reserved.</div>
</div>
</div>
</footer>
<!-- Floating WhatsApp Button -->
<a aria-label="Chat on WhatsApp" class="whatsapp-float" href="https://wa.me/917506251933" target="_blank">
<svg fill="currentColor" height="32" viewbox="0 0 448 512" width="32" xmlns="http://www.w3.org/2000/svg">
<path d="M380.9 97.1C339 55.1 283.2 32 223.9 32c-122.4 0-222 99.6-222 222 0 39.1 10.2 77.3 29.6 111L0 480l117.7-30.9c32.4 17.7 68.9 27 106.1 27h.1c122.3 0 224.1-99.6 224.1-222 0-59.3-25.2-115-67.1-157zm-157 341.6c-33.2 0-65.7-8.9-94-25.7l-6.7-4-69.8 18.3L72 359.2l-4.4-7c-18.5-29.4-28.2-63.3-28.2-98.2 0-101.7 82.8-184.5 184.6-184.5 49.3 0 95.6 19.2 130.4 54.1 34.8 34.9 56.2 81.2 56.1 130.5 0 101.8-84.9 184.6-186.6 184.6zm101.2-138.2c-5.5-2.8-32.8-16.2-37.9-18-5.1-1.9-8.8-2.8-12.5 2.8-3.7 5.6-14.3 18-17.6 21.8-3.2 3.7-6.5 4.2-12 1.4-32.6-16.3-54-29.1-75.5-66-5.7-9.8 5.7-9.1 16.3-30.3 1.8-3.7 .9-6.9-.5-9.7-1.4-2.8-12.5-30.1-17.1-41.2-4.5-10.8-9.1-9.3-12.5-9.5-3.2-.2-6.9-.2-10.6-.2-3.7 0-9.7 1.4-14.8 6.9-5.1 5.6-19.4 19-19.4 46.3 0 27.3 19.9 53.7 22.6 57.4 2.8 3.7 39.1 59.7 94.8 83.8 35.2 15.2 49 16.5 66.6 13.9 10.7-1.6 32.8-13.4 37.4-26.4 4.6-13 4.6-24.1 3.2-26.4-1.3-2.5-5-3.9-10.5-6.6z"></path>
</svg>
<!-- Tooltip -->
<span class="absolute right-full mr-4 bg-ink text-cream text-sm px-3 py-1.5 rounded-lg opacity-0 group-hover:opacity-100 transition-opacity whitespace-nowrap pointer-events-none font-sans">
        Chat with us
      </span>
</a>
</body>
</html>
